<?php
    // Informasi database
    $server = "localhost"; // Ganti dengan nama host database Anda
    $username = "root"; // Ganti dengan nama pengguna database Anda
    $password = ""; // Ganti dengan kata sandi database Anda
    $database = "nusputbarubanget"; // Ganti dengan nama database Anda

    // Membuat koneksi ke database
    $koneksi = new mysqli($server, $username, $password, $database);
    ?>