<?php
include "koneksi.php";
session_start();

$id = $_POST['id'] ?? null;
$nama = $_POST['nama'] ?? null;

$ib1 = $_POST['ib1'] ?? null;
$ib2 = $_POST['ib2'] ?? null;
$ib3 = $_POST['ib3'] ?? null;
$ib4 = $_POST['ib4'] ?? null;
$ib5 = $_POST['ib5'] ?? null;
$ib6 = $_POST['ib6'] ?? null;

$poin_ib1 = 0;
if ($ib1 == "Penulisan artikel online menggunakan media blog") {
    $poin_ib1 = 1;
} else if ($ib1 == "Pembuatan Karya tulis/buku/modul menggunakan media blog") {
    $poin_ib1 = 2;
}

$poin_ib2 = 0;
if ($ib2 == "sederhana") {
    $poin_ib2 = 1;
} else if ($ib2 == "sesuai struktur penulisan modul / buku") {
    $poin_ib2 = 2;
} else if ($ib2 == "sesuai struktur penulisan modul / buku dan diupload di blog/ platform merdeka mengajar") {
    $poin_ib2 = 3;
}

$poin_ib3 = 0;
if ($ib3 == "Guru melaksanakan pendekatan STEAM/STEM dalam bentuk video") {
    $poin_ib3 = 1;
}

$poin_ib4 = 0;
if ($ib4 == "bukan buatan sendiri") {
    $poin_ib4 = 1;
} else if ($ib4 == "buatan sendiri yang sederhana") {
    $poin_ib4 = 2;
} else if ($ib4 == "buatan sendiri yang kreatif") {
    $poin_ib4 = 3;
}

$poin_ib5 = 0;
if ($ib5 == "Publikasi pembelajaran kreatif melalui youtube / tik tok / X-twitter / IG / Facebook Bp/Ibu") {
    $poin_ib5 = 1;
}

$poin_ib6 = 0;
if ($ib6 == "sesuai bidang ilmu yang diampu") {
    $poin_ib6 = 1;
} else if ($ib6 == "secara lengkap,sesuai bidang ilmu yang diampu") {
    $poin_ib6 = 3;
}

$uploads = [
    'berkasib1', 'berkasib11', 'berkasib111', 'berkasib2', 'berkasib22', 'berkasib222',
    'berkasib3', 'berkasib33', 'berkasib333', 'berkasib4',
    'berkasib44', 'berkasib444', 'berkasib5', 'berkasib55', 'berkasib555', 'berkasib6',
    'berkasib66', 'berkasib666'
];

$uploaded_files = [];
foreach ($uploads as $key) {
    if (isset($_FILES[$key]['name']) && $_FILES[$key]['name']) {
        $nama_file = $_FILES[$key]['name'];
        $tmp_file = $_FILES[$key]['tmp_name'];
        $nama_filefull = date("YmdHis") . $id . "_" . $nama_filefull;
   $lokasi_upload = "uploads/" . $nama_filefull ;

        if (move_uploaded_file($tmp_file, $lokasi_upload)) {
            $uploaded_files[$key] = $nama_filefull;
        } else {
            echo "Upload file gagal.";
            exit;
        }
    } else {
        $uploaded_files[$key] = "";
    }
}

$query = "UPDATE tabel_p_pendidikan2 SET 
    nama = '$nama',
    ib1 = '$ib1', poinib1 = $poin_ib1, berkasib1 = '{$uploaded_files['berkasib1']}', berkasib11 = '{$uploaded_files['berkasib11']}', berkasib111 = '{$uploaded_files['berkasib111']}',
    ib2 = '$ib2', poinib2 = $poin_ib2, berkasib2 = '{$uploaded_files['berkasib2']}', berkasib22 = '{$uploaded_files['berkasib22']}', berkasib222 = '{$uploaded_files['berkasib222']}',
    ib3 = '$ib3', poinib3 = $poin_ib3, berkasib3 = '{$uploaded_files['berkasib3']}', berkasib33 = '{$uploaded_files['berkasib33']}', berkasib333 = '{$uploaded_files['berkasib333']}',
    ib4 = '$ib4', poinib4 = $poin_ib4, berkasib4 = '{$uploaded_files['berkasib4']}', berkasib44 = '{$uploaded_files['berkasib44']}', berkasib444 = '{$uploaded_files['berkasib444']}',
    ib5 = '$ib5', poinib5 = $poin_ib5, berkasib5 = '{$uploaded_files['berkasib5']}', berkasib55 = '{$uploaded_files['berkasib55']}', berkasib555 = '{$uploaded_files['berkasib555']}',
    ib6 = '$ib6', poinib6 = $poin_ib6, berkasib6 = '{$uploaded_files['berkasib6']}', berkasib66 = '{$uploaded_files['berkasib66']}', berkasib666 = '{$uploaded_files['berkasib666']}'
    WHERE id = '$id'";

if (mysqli_query($koneksi, $query)) {
    header("Location: page_tombolupload_guru.php");
    exit;
} else {
    echo "Error updating record: " . mysqli_error($koneksi);
}
?>
