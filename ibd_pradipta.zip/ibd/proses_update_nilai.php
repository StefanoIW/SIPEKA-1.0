<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna sudah login sebelumnya
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['id'];

if (isset($_POST['update_nilai'])) {
    // Hitung total poin
    $total_poin_query = "SELECT (COALESCE(poinia1, 0) + COALESCE(poiniab1, 0) + COALESCE(poiniac1, 0) + COALESCE(poinia2, 0) + COALESCE(poinib1, 0) + COALESCE(poinib2, 0) + COALESCE(poinib3, 0) + COALESCE(poinib4, 0) + COALESCE(poinib5, 0) + COALESCE(poinib6, 0) + COALESCE(poinic1, 0) + COALESCE(poinic2, 0) + COALESCE(poinicb2, 0) + COALESCE(poinicc2, 0) + COALESCE(poinicd2, 0) + COALESCE(poinid1, 0) + COALESCE(poinie1, 0)  + COALESCE(poiniia1, 0) + COALESCE(poiniia2, 0) + COALESCE(poiniiab2, 0) + COALESCE(poiniib1, 0) + COALESCE(poiniib2, 0) + COALESCE(poiniib3, 0) + COALESCE(poiniiba3, 0) + COALESCE(poiniib4, 0) + COALESCE(poiniibb4, 0) + COALESCE(poiniibc4, 0) + COALESCE(poiniiia1, 0) + COALESCE(poiniiib1, 0) + COALESCE(poiniiic1, 0) + COALESCE(poiniva1, 0) + COALESCE(poinivb1, 0) + COALESCE(poinivc1, 0) + COALESCE(poinivd1, 0) + COALESCE(poinive1, 0) + COALESCE(poinivea1, 0) + COALESCE(poinive2, 0)) AS total_poin FROM tabel_p_pendidikan2 WHERE id = $id";
    $total_poin_result = $koneksi->query($total_poin_query);

    if ($total_poin_result && $total_poin_result->num_rows > 0) {
        $row = $total_poin_result->fetch_assoc();
        $total_poin = $row['total_poin'];
        
        // Cek apakah total poin adalah nol
        if ($total_poin > 0) {
            $nilai = ($total_poin ) ;
        } else {
            $nilai = 0; // Atau nilai default yang Anda inginkan
        }

        // Update nilai pada tabel_p_pendidikan2
        $update_query = "UPDATE tabel_p_pendidikan2 SET nilai = $nilai WHERE id = $id";
        if ($koneksi->query($update_query) === TRUE) {
            // Redirect ke halaman page_tombolupload_guru.php setelah berhasil mengupdate nilai
            header("Location: page_tombolupload_guru.php");
            exit();
        } else {
            echo "Error: " . $koneksi->error;
        }
    } else {
        echo "Tidak ada poin yang ditemukan.";
    }
}
?>
