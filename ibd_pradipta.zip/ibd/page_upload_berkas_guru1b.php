<?php
session_start();
if (!isset($_SESSION['id']))
{
    header('location:index.php');
    exit;
}
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Guru</title>
    <style>
        html, body {
    height: 100%;
    margin: 0;
    padding: 0;
    background: url('bgnusput.jpg') no-repeat center center fixed;
    background-size: 100% 100%; /* Mengatur ukuran latar belakang sesuai halaman */
    background-position: center center;
    font-family: Arial, sans-serif;

}
.navbar-guru {
    background-color: #3498db; /* Ubah warna background ke warna sebelumnya */
    border: 1px solid #2978a0;
    padding: 10px 0;
    text-align: center; /* Posisi teks navbar di tengah */
}

        .navbar-guru ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .navbar-guru li {
            display: inline;
            margin: 0 20px;
        }

        .navbar-guru a {
            text-decoration: none;
            color: #fff;
            padding: 5px 10px;
            transition: background-color 0.3s, color 0.3s;
        }

        .navbar-guru a:hover {
            background-color: #2978a0;
            color: #fff;
            text-decoration: underline;
        }
        .active {
            background-color: #2978a0;
            color: #fff;
        }

.container {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-group {
        margin-bottom: 20px;
    }

    /* CSS untuk label */
    .form-group label {
        display: block;
        font-weight: bold;
        color: #333; /* Warna teks label */
        margin-bottom: 5px;
    }

    /* CSS untuk input teks */
    .form-group input[type="text"],
    .form-group input[type="email"],
    .form-group select {
        width: 100%;
        padding: 10px;
        margin: 5px 0;
        border: 1px solid #ccc;
        border-radius: 3px;
    }

    /* CSS untuk elemen select */
    .form-group select {
        background: #f9f9f9; /* Warna latar belakang select */
    }

    /* CSS untuk elemen file input */
    .form-group input[type="file"] {
        width: 100%;
        margin-top: 5px;
        /* Tambahkan gaya khusus untuk elemen file input jika diperlukan */
    }

label {
    display: block;
    font-weight: bold;
}

input[type="text"],
select {
    width: 100%;
    padding: 10px;
    margin: 5px 0;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="file"] {
    width: 100%;
    margin-top: 5px;
}

h2 {
    margin-top: 20px;
}
input[type="submit"] {
    background-color: #0073e6; /* Warna biru */
    color: #fff; /* Teks putih */
    padding: 15px 30px; /* Ukuran besar */
    border: none;
    border-radius: 3px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #0052a5; /* Warna biru yang sedikit lebih gelap saat digulirkan */
}
h2, h3 {
    color: blue;
}

</style>
</head>

<body>
<script src="page_proses_berkas_guru.js"></script>
<div class="navbar-guru" id="navbar-guru">
<ul class="nav navbar-nav">
            <li class="active"><a href="page_guru.php">Home</a></li>
            <li><a href="page_profil_guru.php">Profil</a></li>
            <li><a href="page_tombolupload_guru.php">Berkas Portofolio</a></li>
            <li><a href="page_nilai_portofolio_guru.php">Nilai Portofolio</a></li>
            <li><a href="page_lihat_nilai_guru.php">Nilai Rapot</a></li>
            <li><a href="logout.php">Logout</a></li> 
        </ul>
        </div>
    <?php
     $tampilPeg=mysqli_query($koneksi, "SELECT * FROM tabel_jabatan WHERE username='$_SESSION[username]'");
     $peg=mysqli_fetch_array($tampilPeg);
    ?>

    <div class="container">
    <?php
    $currentDate = date('d-m-Y');
    $Q = mysqli_query ($koneksi,"SELECT* FROM tabel_p_pendidikan2");
    $R = mysqli_fetch_array ($Q);
    // Tanggal yang diizinkan untuk mengakses halaman (9 Februari setiap tahun)
    $allowedDate = date('d-m') === '12-02';
    if ($allowedDate || $R['Aktivasi'] == '1') {
        ?>
        
    <form action="proses_upload_1b.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="id">ID Guru:</label>
                <input type="text" class="form-control" id="id" name="id" value="<?php echo $peg['id'];?>" readonly>
            </div>

            <div class="form-group">
                <label for="nama">Nama Guru:</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $peg['nama'];?>" readonly>
            </div>
            <div class="form-group">
     <label for="tahun_penilaian">Tahun penilaian:</label>
      <input type="number" id="tahun_penilaian" name="tahun_penilaian" min="2023" max="2030" >
      <h3>B. hasil karya</h3>
            <div>
                <label for="ib1">1. Karya Tulis/Penulisan artikel online bidang pendidikan menggunakan media Blog</label>
                <select name="ib1" id="ib1">]
                    <option></option>
                    <option>Tidak pernah</option>
                    <option>Penulisan artikel online menggunakan media blog</option>
                    <option>Pembuatan Karya tulis/buku/modul menggunakan media blog</option>
                </select>
                <div class="form-group">
        <label for="berkasib1"style="text-decoration: underline;">Dibuktikan dengan dokumen Karya Tulis / Penulisan artikel online di blog  sesuai kompetensi bidang ilmu yang diampu ( menginformasikan alamat blog yang memuat dokumen tsb ):</label>
        <input type="file" id="berkasib1" name="berkasib1" >
    </div>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    var ib1 = document.getElementById('ib1');
    var berkasib1 = document.getElementById('berkasib1');

    // Function to show or hide file inputs based on selected option
    function toggleFileInputs() {
        if (ib1.value === 'Tidak pernah') {
            berkasib1.style.display = 'none';
        } else {
            berkasib1.style.display = 'block';
 
        }
    }

    // Toggle file inputs on page load
    toggleFileInputs();

    // Toggle file inputs when option is changed
    ib1.addEventListener('change', function() {
        toggleFileInputs();
    });

    // Form submission validation
    var form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if ((ib1.value === 'Penulisan artikel online menggunakan media blog' || ib1.value === 'Pembuatan Karya tulis/buku/modul menggunakan media blog') && (berkasib1.value === '' || berkasib11.value === '')) {
            event.preventDefault(); // Prevent form submission
            alert('Mohon isi semua berkas jika memilih opsi Penulisan artikel online atau Pembuatan Karya tulis/buku/modul menggunakan media blog');
        }
    });
});
</script>

            <div>
                <label for="ib2">2. E-modul/E-book sesuai mata pelajaran yang diampu atau keunggulan sekolah </label>
               
                <select name="ib2" id="ib2">
                    <option></option>
                    <option>Tidak pernah</option>
                    <option >sederhana</option>
                    <option >sesuai struktur penulisan modul / buku</option>
                    <option>sesuai struktur penulisan modul / buku dan diupload di blog/ platform merdeka mengajar</option>
                </select>
                <div class="form-group">
        <label for="berkasib2"style="text-decoration: underline;">Dokumen E-Modul/E-Book  diunggah ke dalam blog:</label>
        <input type="file" id="berkasib2" name="berkasib2" >
    </div>

    <div class="form-group" style="display: none;">
        <label for="berkasib22">Berkas 2:</label>
        <input type="file" id="berkasib22" name="berkasib22">
    </div>

    <!-- Add file input for berkasiaaa1 -->
    <div class="form-group" style="display: none;">
        <label for="berkasib222">Berkas 3:</label>
        <input type="file" id="berkasib222" name="berkasib222" >
    </div>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var ib2 = document.getElementById('ib2');
    var berkasib2 = document.getElementById('berkasib2');
    var berkasib22 = document.getElementById('berkasib22');
    var berkasib222 = document.getElementById('berkasib222');

    // Function to show or hide file inputs based on selected option
    function toggleFileInputs() {
        if (ib2.value === 'Tidak pernah') {
            berkasib2.style.display = 'none';
            berkasib22.style.display = 'none';
            berkasib222.style.display = 'none';
        } else {
            berkasib2.style.display = 'block';
            berkasib22.style.display = 'block';
            berkasib222.style.display = 'block';
        }
    }

    // Toggle file inputs on page load
    toggleFileInputs();

    // Toggle file inputs when option is changed
    ib2.addEventListener('change', function() {
        toggleFileInputs();
    });

    // Form submission validation
    var form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if ((ib2.value === 'sederhana' || ib2.value === 'sesuai struktur penulisan modul / buku' || ib2.value === 'sesuai struktur penulisan modul / buku dan diupload di blog/ platform merdeka mengajar') && (berkasib2.value === '')) {
            event.preventDefault(); // Prevent form submission
            alert('Mohon isi semua berkas jika memilih opsi sederhana atau sesuai struktur penulisan modul / buku');
        }
    });
});
</script>

            <div>
                <label for="ib3">3. Pendekatan STEAM/STEM </label>
                <select name="ib3" id="ib3">
                    <option></option>
                    <option>Tidak pernah</option>
                    <option>Guru melaksanakan pendekatan STEAM/STEM dalam bentuk video</option>
                </select>
                <div class="form-group">
        <label for="berkasib3" style="text-decoration: underline;">Video pembelajaran  dengan menggunakan pendekatan STEAM/STEM(menggunakan link berbentuk pdf) :</label>
        <input type="file" id="berkasib3" name="berkasib3" >
    </div>

    <div class="form-group" style="display: none;">
        <label for="berkasib33">Berkas 2:</label>
        <input type="file" id="berkasib33" name="berkasib33">
    </div>

    <!-- Add file input for berkasiaaa1 -->
    <div class="form-group" style="display: none;">
        <label for="berkasib333">Berkas 3:</label >
        <input type="file" id="berkasib333" name="berkasib333" >
    </div>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    var ib3 = document.getElementById('ib3');
    var berkasib3 = document.getElementById('berkasib3');
    var berkasib33 = document.getElementById('berkasib33');
    var berkasib333 = document.getElementById('berkasib333');

    // Function to show or hide file inputs based on selected option
    function toggleFileInputs() {
        if (ib3.value === 'Tidak pernah') {
            berkasib3.style.display = 'none';
            berkasib33.style.display = 'none';
            berkasib333.style.display = 'none';
        } else {
            berkasib3.style.display = 'block';
            berkasib33.style.display = 'block';
            berkasib333.style.display = 'block';
        }
    }

    // Toggle file inputs on page load
    toggleFileInputs();

    // Toggle file inputs when option is changed
    ib3.addEventListener('change', function() {
        toggleFileInputs();
    });

    // Form submission validation
    var form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if (ib3.value === 'Guru melaksanakan pendekatan STEAM/STEM dalam bentuk video' && (berkasib3.value === '')) {
            event.preventDefault(); // Prevent form submission
            alert('Mohon isi semua berkas jika memilih opsi Guru melaksanakan pendekatan STEAM/STEM dalam bentuk video');
        }
    });
});
</script>

            <div>
                <label for="ib4">4. Penggunaan alat peraga </label>
               

                <select name="ib4" id="ib4">
                    <option></option>
                    <option>Tidak pernah</option>
                    <option >bukan buatan sendiri	</option>
                    <option >buatan sendiri	yang sederhana	</option>
                    <option >buatan sendiri yang kreatif</option>

                </select>
                <div class="form-group" >
        <label for="berkasib4"style="text-decoration: underline;">Foto/video alat peraga saat digunakan dalam proses pembelajaran yang dibuat oleh guru:</label>
        <input type="file" id="berkasib4" name="berkasib4" >
    </div>

    <div class="form-group" style="display: none;">
        <label for="berkasib44">Berkas 2:</label>
        <input type="file" id="berkasib44" name="berkasib44">
    </div>

    <!-- Add file input for berkasiaaa1 -->
    <div class="form-group" style="display: none;">
        <label for="berkasib444">Berkas 3:</label>
        <input type="file" id="berkasib444" name="berkasib444" >
    </div>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    var ib4 = document.getElementById('ib4');
    var berkasib4 = document.getElementById('berkasib4');
    var berkasib44 = document.getElementById('berkasib44');
    var berkasib444 = document.getElementById('berkasib444');

    // Function to show or hide file inputs based on selected option
    function toggleFileInputs() {
        if (ib4.value === 'Tidak pernah') {
            berkasib4.style.display = 'none';
            berkasib44.style.display = 'none';
            berkasib444.style.display = 'none';
        } else {
            berkasib4.style.display = 'block';
            berkasib44.style.display = 'block';
            berkasib444.style.display = 'block';
        }
    }

    // Toggle file inputs on page load
    toggleFileInputs();

    // Toggle file inputs when option is changed
    ib4.addEventListener('change', function() {
        toggleFileInputs();
    });

    // Form submission validation
    var form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if ((ib4.value === 'bukan buatan sendiri' || ib4.value === 'buatan sendiri	yang sederhana' || ib4.value === 'buatan sendiri yang kreatif') && (berkasib4.value === '')) {
            event.preventDefault(); // Prevent form submission
            alert('Mohon isi semua berkas jika memilih opsi bukan buatan sendiri atau buatan sendiri yang sederhana atau buatan sendiri yang kreatif');
        }
    });
});
</script>

            <div>
                <label for="ib5">5. Publikasi pembelajaran kreatif  melalui youtube / tik tok / X-twitter / IG / Facebook </label>
               
                <select name="ib5" id="ib5">
                    <option></option>
                    <option>Tidak pernah</option>
                    <option >Publikasi pembelajaran kreatif melalui youtube / tik tok / X-twitter / IG / Facebook Bp/Ibu</option>
                </select>
                <div class="form-group">
        <label for="berkasib5"style="text-decoration: underline;">Video yang sudah terunggah pada youtube/tik tok/ X / IG/Fb pribadi guru masing2 (mencantumkan link medsos pribadi Bp/Ibu dalam bentuk pdf):</label>
        <input type="file" id="berkasib5" name="berkasib5" >
    </div>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    var ib5 = document.getElementById('ib5');
    var berkasib5 = document.getElementById('berkasib5');

    // Function to show or hide file inputs based on selected option
    function toggleFileInputs() {
        if (ib5.value === 'Tidak pernah') {
            berkasib5.style.display = 'none';
        } else {
            berkasib5.style.display = 'block';
        }
    }

    // Toggle file inputs on page load
    toggleFileInputs();

    // Toggle file inputs when option is changed
    ib5.addEventListener('change', function() {
        toggleFileInputs();
    });

    // Form submission validation
    var form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if (ib5.value === 'Publikasi pembelajaran kreatif melalui youtube / tik tok / X-twitter / IG / Facebook Bp/Ibu' && (berkasib5.value === '')) {
            event.preventDefault(); // Prevent form submission
            alert('Mohon isi semua berkas jika memilih opsi Publikasi pembelajaran kreatif melalui youtube / tik tok / X-twitter / IG / Facebook Bp/Ibu');
        }
    });
});
</script>
<div>
<label for="ib6">6.PTK (Penelitian Tindakan Kelas) / BP ( Best Practice )</label>

<select name="ib6" id="ib6">
    <option></option>
    <option>Tidak pernah</option>
    <option >sesuai bidang ilmu yang diampu</option>
    <option >secara lengkap,sesuai bidang ilmu yang diampu</option>
</select>
<div class="form-group">
<label for="berkasib6"style="text-decoration: underline;">Dibuktikan dengan laporan PTK / BP :</label>
<input type="file" id="berkasib6" name="berkasib6" ">
</div>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var ib6 = document.getElementById('ib6');
    var berkasib6 = document.getElementById('berkasib6');

    // Function to show or hide file inputs based on selected option
    function toggleFileInputs() {
        if (ib6.value === 'Tidak pernah') {
            berkasib6.style.display = 'none';
        } else {
            berkasib6.style.display = 'block';
        }
    }

    // Toggle file inputs on page load
    toggleFileInputs();

    // Toggle file inputs when option is changed
    ib6.addEventListener('change', function() {
        toggleFileInputs();
    });

    // Form submission validation
    var form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        if ((ib6.value === 'sesuai bidang ilmu yang diampu' || ib6.value === 'secara lengkap,sesuai bidang ilmu yang diampu' ) && (berkasib6.value === '')) {
            event.preventDefault(); // Prevent form submission
            alert('Mohon isi semua berkas di PTK (Penelitian Tindakan Kelas) / BP ( Best Practice )');
        }
    });
});
</script>
</div>
    </div>   
           
            
            <input type="submit" value="submit">
        </form>
        <?php
    } else {
        echo "<h2 class='text-center' style='color: red;'>*Report : Maaf, Anda tidak dapat mengakses halaman ini. Halaman ini hanya dapat diakses pada tanggal yang sudah ditentukan.</h2>";
    }
?> 
        </body>
</html>