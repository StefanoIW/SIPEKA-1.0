    <?php 
session_start();
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form page_register_kepsek.php

$nama = $_POST['nama'];
$tgl_lahir = $_POST['tgl_lahir'];
$username = $_POST['username'];
$password = md5($_POST['password']);
$jabatan = $_POST['jabatan'];
$jenjang = $_POST['jenjang'];
$tahunpenilaian = $_POST['tahunpenilaian'];
$matapelajaran = $_POST['matapelajaran'];

if ($_FILES['berkas']['name']) {
    $nama_file = $_FILES['berkas']['name'];
    $tmp_file = $_FILES['berkas']['tmp_name'];
    $lokasi_upload = "uploads/" . $nama_file;
 
    // Pindahkan file ke folder tujuan
    if (move_uploaded_file($tmp_file, $lokasi_upload)) {
        // File berhasil diupload
    } else {
        // File gagal diupload
        echo "Upload file gagal.";
        exit;
    }
 } else {
    $nama_file = ""; // Jika tidak ada file yang diupload, set nama file menjadi kosong
 }
 
// menginput data ke database
mysqli_query($koneksi,"insert into tabel_jabatan (nama,tgl_lahir,username,password,jabatan,jenjang,angkatan) values('$nama','$tgl_lahir','$username','$password','$jabatan','$jenjang','$tahunpenilaian')");
$sql="select * from tabel_jabatan where username = '$username'";
$query = mysqli_query($koneksi, $sql);
$row=mysqli_fetch_array($query);
$id=$row['id'];
mysqli_query($koneksi, "INSERT INTO tabel_karyawan (id, nama, jenjang,mata_pelajaran,jabatan, angkatan,foto_profil) 
VALUES ('$id', '$nama','$jenjang', '$matapelajaran','$jabatan', '$tahunpenilaian','$nama_file')");

// mengalihkan halaman kembali ke tambahpegawaisdm.php
// mengalihkan halaman kembali ke tambahpegawaisdm.php
header("location:page_register_admin.php");
 
?>